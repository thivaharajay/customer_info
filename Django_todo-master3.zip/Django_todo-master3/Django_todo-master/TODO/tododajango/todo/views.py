from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect 
from .models import products,products1

def todohome(request):
    todoobjects = products.objects.all()

    return render(request, 'home.html', {'todohomeitem': todoobjects})
def todoView(request):
    todoobjects=products.objects.all()
    
    return render(request,'todo.html',{'todoitem':todoobjects})


def todoproducts(request):
    todoobjects = products1.objects.all()

    return render(request, 'todo1.html', {'todo1item': todoobjects})


# Create your views here.


def additem(request):
    # create todo item 
    # save the item to database
    # redirect to toditem
    # fint the name=contetn 
   
    add_name = products(name = 'name' in request.POST and request.POST['name'],
                        address = 'address' in request.POST and request.POST['address'],
                        phoneNumber = 'phonenumber' in request.POST and request.POST['phonenumber'],
                        pinCode = 'pincode' in request.POST and request.POST['pincode'])
    
    #products.save()
    add_name.save()
    
    return HttpResponseRedirect('/customer/')
    db.connections.close_all()

def additem1(request):
    add_name1 = products1(name='name' in request.POST and request.POST['name'],
                        volplus='volplus' in request.POST and request.POST['volplus'],
                        volUNLD='volUNLD' in request.POST and request.POST['volUNLD'],
                        volSUPER='volSUPER' in request.POST and request.POST['volSUPER'],
                        SUPER='SUPER' in request.POST and request.POST['SUPER'],
                        volCDIESEL='volCDIESEL' in request.POST and request.POST['volCDIESEL'],
                        CDIESEL='CDIESEL' in request.POST and request.POST['CDIESEL'],
                        volRDIESEL='volRDIESEL' in request.POST and request.POST['volRDIESEL'],
                        RDIESEL='RDIESEL' in request.POST and request.POST['RDIESEL'],
                        OIL='OIL' in request.POST and request.POST['OIL'],
                        MISC='MISC' in request.POST and request.POST['MISC'],
                        TAX='TAX' in request.POST and request.POST['TAX'],
                        AMT_TOTAL='AMT_TOTAL' in request.POST and request.POST['AMT_TOTAL'])


    # products.save()
    add_name1.save()

    return HttpResponseRedirect('/product1/')
    db.connections.close_all()
def deleteitem(request, todo_id):
    # delete todo item
    itemdelete=products.objects.get(id=todo_id)
    itemdelete.delete()
    
    return HttpResponseRedirect('/customer/')
