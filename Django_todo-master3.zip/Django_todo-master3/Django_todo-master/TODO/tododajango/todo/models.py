from django.db import models

#class todoitem(models.Model):
  #  content=models.TextField()
 #   fn=models.TextField(null=True)

#products table
class products1(models.Model):
    name = models.TextField(default="None")
    volplus= models.IntegerField(null=True)
    volUNLD = models.IntegerField(null=True)
    volSUPER = models.IntegerField(null=True)
    SUPER = models.IntegerField(null=True)
    volCDIESEL = models.IntegerField(null=True)
    CDIESEL = models.IntegerField(null=True)
    volRDIESEL = models.IntegerField(null=True)
    RDIESEL = models.IntegerField(null=True)
    OIL = models.IntegerField(null=True)
    MISC = models.IntegerField(null=True)
    TAX = models.IntegerField(null=True)
    AMT_TOTAL = models.IntegerField(null=True)

#customer table
class products(models.Model):
    name = models.TextField(default="None")
    phoneNumber = models.IntegerField(null=True)
    address = models.TextField(null=True)
    pinCode = models.IntegerField(null=True)

# Create your models here.
