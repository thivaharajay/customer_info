from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import product_details, customer,updated,customerupdated,productupdated

from django.contrib import messages


def productView(request):
    #renders the products.html
    productObjects=product_details.objects.all()
    return render(request,'products.html',{'product_details':productObjects})

def homeView(request):
    #renders the products.html

    return render(request,'home.html')

def customerView(request):
    #renders the products.html
    customerObjects=customer.objects.get(id=1)
    return render(request,'customers.html',{'customer':customerObjects})

def updatedview(request):
    #renders the products.html
    updatedobjects=updated.objects.all()
    return render(request,'cus.html',{'updated':updatedobjects})


def addProduct(request):

   # category=request.POST.get('va')
    volPlus=int(request.POST['volPlus'])
    volUNLD=int(request.POST['volUNLD'])
    volSUPER=int(request.POST['volSUPER'])
    SUPER=int(request.POST['SUPER'])
    volCDIESEL=int(request.POST['volCDIESEL'])
    CDIESEL=int(request.POST['CDIESEL'])
    volRDIESEL=int(request.POST['volRDIESEL'])
    RDIESEL=int(request.POST['RDIESEL'])
    OIL=int(request.POST['OIL'])
    MISC=int(request.POST['MISC'])
    TAX=int(request.POST['TAX'])
    add_prod = product_details(productName=request.POST['productName'],
                                volPlus=request.POST['volPlus'],
                                volUNLD=request.POST['volUNLD'],
                                volSUPER=request.POST['volSUPER'],
                                SUPER=request.POST['SUPER'],
                                volCDIESEL=request.POST['volCDIESEL'],
                                CDIESEL=request.POST['CDIESEL'],
                                volRDIESEL=request.POST['volRDIESEL'],
                                RDIESEL=request.POST['RDIESEL'],
                                OIL=request.POST['OIL'],
                                MISC=request.POST['MISC'],
                                TAX=request.POST['TAX'],
                                AMT_TOTAL=volPlus+volUNLD+volSUPER+SUPER+volCDIESEL+CDIESEL+volRDIESEL+RDIESEL+OIL+MISC+TAX
                                )

    add_prod.save()
    return HttpResponseRedirect('/products/')
    #db.connection.close_all()
def addCustomer(request):
    add_cus=customer(customerName = request.POST['customerName'],
                        phoneNumber = request.POST['phoneNumber'],
                        address = request.POST['address'],
                        pinCode = request.POST['pinCode'])
    add_cus.save()

    return HttpResponseRedirect('/customer/')


def addupdated(request):
    add_upt = updated(name=request.POST['name'])

    add_upt.save()

    return HttpResponseRedirect('/updated/')



def customerupdatedview(request):
    #renders the products.html
    customerupdatedObjects=customerupdated.objects.all()
    return render(request,'customerupdated.html',{'customerupdated':customerupdatedObjects})
#updated customer
def addcustomerupdated(request):
    add_updatedcus=customerupdated(Customer_Id = request.POST['Customer_Id'],
                                   Customername = request.POST['Customername'],
                                   Street_address = request.POST['Street_address'],
                                   Address_line2 = request.POST['Address_line2'],
                                   City = request.POST['City'],
                                   State = request.POST['State'],
                                   Country = request.POST['Country'],
                                   Zip_code = request.POST['Zip_code'],
                                   Email=request.POST['Email'],
                                   Phonenumber = request.POST['Phonenumber'])
    add_updatedcus.save()

    return HttpResponseRedirect('/cusupdated/')



def productupdatedview(request):
    #renders the products.html
    productupdatedObjects=productupdated.objects.all()
    return render(request,'productupdated.html',{'productupdated':productupdatedObjects})
#productupdated
def addproductupdated(request):

   # category=request.POST.get('va')

    # Price_PLUS =int(request.POST['Price_PLUS'])
    # Price_UNLD=int(request.POST['Price_UNLD'])
    # Price_SUPER=int(request.POST['Price_SUPER'])
    # Price_CDIESEL=int(request.POST['Price_CDIESEL'])
    # Price_RDIESEL=int(request.POST['Price_RDIESEL'])
    # OIL=int(request.POST['OIL'])
    # MISC=int(request.POST['MISC'])
    # TAX=int(request.POST['TAX'])
    add_updatedpro = productupdated(#Customer_Id = request.POST['Customer_Id'],
                                     Invoice_date = (request.POST['Invoice_date']),
                                     Invoice_number =(request.POST['Invoice_number']),
                                     vol_PLUS = (request.POST['vol_PLUS']),
                                     price_PLUS = (request.POST['price_PLUS']),
                                     vol_UNLD =(request.POST['vol_UNLD']),
                                     price_UNLD = (request.POST['price_UNLD']),
                                     vol_SUPER = (request.POST['vol_SUPER']),
                                     price_SUPER = request.POST['price_SUPER'],
                                     vol_CDIESEL =(request.POST['vol_CDIESEL']),
                                     price_CDIESEL = (request.POST['price_CDIESEL']),
                                     vol_RDIESEL = (request.POST['vol_RDIESEL']),
                                     price_RDIESEL=(request.POST['price_RDIESEL']),
                                     OIL = (request.POST['OIL']),
                                     MISC =(request.POST['MISC']),
                                     TAX = request.POST['TAX'],
                                    # AMT_TOTAL=request.POST['AMT_TOTAL'],
                                )

    add_updatedpro.save()

    return HttpResponseRedirect('/proupdated/')