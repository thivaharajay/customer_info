from django.db import models

# Create your models here.

class product_details(models.Model):
    productName = models.TextField(null=True)
    produtID = models.IntegerField(null=True)
    volPlus= models.IntegerField(null=True)
    volUNLD = models.IntegerField(null=True)
    volSUPER = models.IntegerField(null=True)
    SUPER = models.IntegerField(null=True)
    volCDIESEL = models.IntegerField(null=True)
    CDIESEL = models.IntegerField(null=True)
    volRDIESEL = models.IntegerField(null=True)
    RDIESEL = models.IntegerField(null=True)
    OIL = models.IntegerField(null=True)
    MISC = models.IntegerField(null=True)
    TAX = models.IntegerField(null=True)
    AMT_TOTAL = models.IntegerField(null=True)

class customer(models.Model):
    customerName = models.TextField(null=True)
    phoneNumber = models.IntegerField(null=True)
    address = models.TextField(null=True)
    pinCode = models.IntegerField(null=True)

class updated(models.Model):
    name = models.TextField(null=True)

class updatedwes(models.Model):
    name = models.TextField(null=True)

class good(models.Model):
    name = models.TextField(null=True)

class customerupdated(models.Model):
    Customer_Id = models.AutoField(primary_key=True)
    Customername = models.TextField(null=True)
    Street_address = models.TextField(null=True)
    Address_line2 = models.TextField(null=True)
    City = models.TextField(null=True)
    State = models.TextField(null=True)
    Country = models.TextField(null=True)
    Zip_code = models.IntegerField(null=True)
    Email = models.TextField(null=True)
    Phonenumber = models.IntegerField(null=True)


class productupdated(models.Model):
   # Customer_Id = models.ForeignKey(customerupdated, null=True, db_column="Customer_Id", on_delete=models.CASCADE)
    Invoice_date = models.IntegerField(null=True)
    Invoice_number = models.IntegerField(null=True)
    vol_PLUS = models.IntegerField(null=True)
    price_PLUS = models.IntegerField(null=True)
    vol_UNLD = models.IntegerField(null=True)
    Price_UNLD = models.IntegerField(null=True)
    vol_SUPER = models.IntegerField(null=True)
    price_SUPER = models.IntegerField(null=True)
    vol_CDIESEL = models.IntegerField(null=True)
    price_CDIESEL = models.IntegerField(null=True)
    vol_RDIESEL = models.IntegerField(null=True)
    price_RDIESEL = models.IntegerField(null=True)
    OIL = models.IntegerField(null=True)
    MISC = models.IntegerField(null=True)
    TAX = models.IntegerField(null=True)

    AMT_TOTAL = models.IntegerField(null=True)
#upup
class upup(models.Model):
   # Customer_Id = models.ForeignKey(customerupdated, null=True, db_column="Customer_Id", on_delete=models.CASCADE)
    Invoice_date = models.IntegerField(null=True)
    Invoice_number = models.IntegerField(null=True)
    vol_PLUS = models.IntegerField(null=True)
    price_PLUS = models.IntegerField(null=True)
    vol_UNLD = models.IntegerField(null=True)
    Price_UNLD = models.IntegerField(null=True)
    vol_SUPER = models.IntegerField(null=True)
    price_SUPER = models.IntegerField(null=True)
    vol_CDIESEL = models.IntegerField(null=True)
    price_CDIESEL = models.IntegerField(null=True)
    vol_RDIESEL = models.IntegerField(null=True)
    price_RDIESEL = models.IntegerField(null=True)
    OIL = models.IntegerField(null=True)
    MISC = models.IntegerField(null=True)
    TAX = models.IntegerField(null=True)

    AMT_TOTAL = models.IntegerField(null=True)