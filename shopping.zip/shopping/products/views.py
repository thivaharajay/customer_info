from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import product_details, customer,updated,customerupdated,productupdated

from django.contrib import messages


def productView(request):
    #renders the products.html
    productObjects=product_details.objects.all()
    return render(request,'products.html',{'product_details':productObjects})

def homeView(request):
    #renders the products.html

    return render(request,'home.html')

def customerView(request):
    #renders the products.html
    customerObjects=customer.objects.get(id=1)
    return render(request,'customers.html',{'customer':customerObjects})

def updatedview(request):
    #renders the products.html
    updatedobjects=updated.objects.all()
    return render(request,'cus.html',{'updated':updatedobjects})


def addProduct(request):

   # category=request.POST.get('va')
    volPlus=int(request.POST['volPlus'])
    volUNLD=int(request.POST['volUNLD'])
    volSUPER=int(request.POST['volSUPER'])
    SUPER=int(request.POST['SUPER'])
    volCDIESEL=int(request.POST['volCDIESEL'])
    CDIESEL=int(request.POST['CDIESEL'])
    volRDIESEL=int(request.POST['volRDIESEL'])
    RDIESEL=int(request.POST['RDIESEL'])
    OIL=int(request.POST['OIL'])
    MISC=int(request.POST['MISC'])
    TAX=int(request.POST['TAX'])
    add_prod = product_details(productName=request.POST['productName'],
                                volPlus=request.POST['volPlus'],
                                volUNLD=request.POST['volUNLD'],
                                volSUPER=request.POST['volSUPER'],
                                SUPER=request.POST['SUPER'],
                                volCDIESEL=request.POST['volCDIESEL'],
                                CDIESEL=request.POST['CDIESEL'],
                                volRDIESEL=request.POST['volRDIESEL'],
                                RDIESEL=request.POST['RDIESEL'],
                                OIL=request.POST['OIL'],
                                MISC=request.POST['MISC'],
                                TAX=request.POST['TAX'],
                                AMT_TOTAL=volPlus+volUNLD+volSUPER+SUPER+volCDIESEL+CDIESEL+volRDIESEL+RDIESEL+OIL+MISC+TAX
                                )

    add_prod.save()
    return HttpResponseRedirect('/products/')
    #db.connection.close_all()
def addCustomer(request):
    add_cus=customer(customerName = request.POST['customerName'],
                        phoneNumber = request.POST['phoneNumber'],
                        address = request.POST['address'],
                        pinCode = request.POST['pinCode'])
    add_cus.save()

    return HttpResponseRedirect('/customer/')


def addupdated(request):
    add_upt = updated(name=request.POST['name'])

    add_upt.save()

    return HttpResponseRedirect('/updated/')


#updated customer
def addCustomerupdated(request):
    add_updatedcus=customerupdated(customername = request.POST['customername'],
                                   Street_address = request.POST['address'],
                                   Address_line2 = request.POST['Address_line2'],
                                   City = request.POST['City'],
                                   state = request.POST['state'],
                                   Country = request.POST['Country'],
                                   Zip_code = request.POST['pinCode'],
                                   Email=request.POST['Email'],
                                   PhoneNumber = request.POST['phoneNumber'])
    add_updatedcus.save()

    return HttpResponseRedirect('/customerupdated/')



def productupdatedView(request):
    #renders the products.html
    productupdatedObjects=product_details.objects.all()
    return render(request,'productupdated.html',{'product_details':productupdatedObjects})
#productupdated
def addProductupdated(request):

   # category=request.POST.get('va')
    Invoice_date = (request.POST['Invoice_date'])
    Invoice_number = (request.POST['Invoice_number'])
    vol_PLUS=int(request.POST['vol_PLUS'])
    Price_PLUS = int(request.POST['Price_PLUS'])
    vol_UNLD = int(request.POST['vol_UNLD'])
    Price_UNLD=int(request.POST['Price_UNLD'])
    Vol_SUPER=int(request.POST['vol_SUPER'])
    Price_SUPER=int(request.POST['Price_SUPER'])
    Vol_CDIESEL=int(request.POST['Vol_CDIESEL'])
    Price_CDIESEL=int(request.POST['Price_CDIESEL'])
    Vol_RDIESEL=int(request.POST['Vol_RDIESEL'])
    Price_RDIESEL=int(request.POST['Price_RDIESEL'])
    OIL=int(request.POST['OIL'])
    MISC=int(request.POST['MISC'])
    TAX=int(request.POST['TAX'])
    add_produpdated = productupdated(Invoice_date=request.POST['Invoice_date'],
                                     Invoice_number=request.POST['Invoice_number'],
                                     Price_PLUS=request.POST['vol_PLUS'],
                                     Price_UNLD=request.POST['volUNLD'],
                                     Price_SUPER=request.POST['volSUPER'],
                                     Price_CDIESEL=request.POST['volCDIESEL'],
                                     Price_RDIESEL=request.POST['Price_RDIESEL'],
                                     OIL=request.POST['OIL'],
                                     MISC=request.POST['MISC'],
                                     TAX=request.POST['TAX'],
                                     AMT_TOTAL=Price_UNLD+Price_UNLD+Price_SUPER+Price_CDIESEL+Price_RDIESEL+OIL+MISC+TAX
                                )

    add_produpdated.save()
    return HttpResponseRedirect('/productupdated/')